#include <unistd.h>
#include <stdio.h>

int main(int argc, char **argv)
{
	int c, w=0;

	while ( (c=getchar()) != EOF)
	{
		if (c == '\n')
		{
			if ( (c=getchar()) == EOF)
				break;

			ungetc(c, stdin);

			while (!w || (w % 80))
			{
				w++;
				putchar(' ');
			}
			w = 0;
			continue;
		}

		w++;
		putchar(c);
	}
}
